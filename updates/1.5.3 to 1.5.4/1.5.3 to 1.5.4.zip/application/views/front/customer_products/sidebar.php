<aside class="col-md-3 sidebar hidden-sm hidden-xs" id="sidebar">
    <div class="row">
    <?php
    	echo $this->html_model->widget('customer_advance_search');
		echo $this->html_model->widget('special_products');
	?>
    </div>
</aside>